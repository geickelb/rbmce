import os

data_path='/share/fsmresfiles/gje1631/infection'
code_path='/home/gje1631/nmedw_py'
#nelson_data_path='R:\PrevMed\HBMI\LYG\LabWorkstationMount\gje1631\infection\Nelson_files'
output_path= os.path.join(data_path, 'amalgam')
data_path= os.path.join(data_path, 'Nelson_files')



specified_date= '10_09_2021'
n_latex_rows=10